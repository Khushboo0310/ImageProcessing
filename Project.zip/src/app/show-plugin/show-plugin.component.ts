import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-show-plugin',
  templateUrl: './show-plugin.component.html',
  styleUrls: ['./show-plugin.component.css']
})
export class ShowPluginComponent implements OnInit {
  plugin:string;

  constructor(private route:ActivatedRoute, private http: HttpClient) { }

  ngOnInit() {
    this.route.queryParams
    .subscribe(params =>{
      console.log(params);
      this.plugin = params.plugin;
      console.log(this.plugin);

      this.http.get("http://localhost:5000/"+this.plugin)
      .subscribe(data=>{
        console.log(this.plugin,data);
      });

    });
  }

}
